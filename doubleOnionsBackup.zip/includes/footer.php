<footer class="footer">
    <div class="container">
        <div class="row justify-content-around">
            <div class="col-md-6">
                <a href="mailto:22onions@gmail.com"><i class="far fa-envelope fa-2x">   </i></a>
                <a href="http://www.instagram.com/doubleonions/" target="_blank"><i class="fab fa-instagram fa-2x"></i></a>
                <a href="https://www.facebook.com/doubleonions/" target="_blank"><i class="fab fa-facebook-square fa-2x"></i></a>
            </div>
            <div class="col-md-6 footer-form">
                 <p> Join our newsletter: </p>
                <form class="newsletter-form" action="includes/addToNewsletter.php" method=POST style="margin:auto;max-width:235px">
                    <input type="text" name="nlEmail" placeholder="Email">
                    <input type="hidden" name="prevPage" value="">
                    <button type="submit" id="submit-button">Join</button>
                </form>
            </div>
        </div>
    </div>
</footer>