  <div class="jumbotron jumbotron-fluid">
      <div class="container-fluid">
    <h1>Welcome...</h1>
    <h5>Nothing is currently in stock but you can help me decide which items to purchase by voting below!</h5>
    </div>
  </div>